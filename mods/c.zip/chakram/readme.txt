License: CC0

Version: 4.1

The tool is a weapon at same time
Throw it and it will always return as long there still is velocity/power left
It can pick up stuff that is breakable by hand (like no use by tools) and mobs/drops that have 10hp or less.
Players (or mobs that have more then 10 hp) will be hurted.

Craft: Wood:
S = Stick
w = Wood
[S] [  ] [S]
[  ] [w] [  ]
[S] [  ] [S]

Craft: Steel:
S = Steel ingot
B = Steel block
[S] [  ] [S]
[  ] [B] [  ]
[S] [  ] [S]

Craft: Mese:
C = Mese crystal
B = Mese block
[C] [  ] [C]
[  ] [B] [  ]
[C] [  ] [C]